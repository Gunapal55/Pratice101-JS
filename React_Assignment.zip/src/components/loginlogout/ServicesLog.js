
import React from 'react';

import {Redirect} from 'react-router-dom'
import {Link} from 'react-router-dom';

class Services extends React.Component {
    constructor(props){
        super(props);
        const token = localStorage.getItem("token")

        let loggedIn =true
        if(token == null){
            loggedIn = false

        }
        this.state ={
            loggedIn
        }
    }
    render() { 
        if (this.state.loggedIn === false) {

            return <Redirect to="/logout"/>
            
        }
        return ( 
            <div>
              <h1>{this.state.loggedIn}</h1>  
                  <nav class="navbar navbar-expand-lg navbar-light bg-danger">
  <div class="container-fluid">
    <h1>Employe</h1>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Contact</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Services</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
        </li>
      </ul>
      <form class="d-flex">
        
      <Link to="/login"><button type="button" class="btn btn-dark" >Login</button></Link>
      <Link to="/register"><button type="button" class="btn btn-dark">Register</button></Link>

          </form>
        </div>
      </div>
   </nav>
</div>
         );
    }
}
 
export default Services;

