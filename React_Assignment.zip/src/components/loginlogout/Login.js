
import React from 'react';
// import { useHistory } from "react-router-dom";


 import {Redirect,Link, useHistory} from "react-router-dom";
 
export default class Login extends React.Component {
    constructor(props){
        super(props);
       
        
        this.state={
            usernam:'',
            password:'',
            loggedIn:false
        }
        this.onChange =this.onChange.bind(this)
        this.submitForm =this.submitForm.bind(this)

    }
    onChange(e){
        this.setState({
            [e.target.name]:e.target.value
        })
    }
    submitForm(e){
        e.preventDefault()
        this.props.history.push("/logout");
        
    }

    render() { 
      if(this.state.loggedIn){
        console.log("Inside");
          return <Redirect to="/"/>
      }
       
        
        return (  
            <div>
    <nav class="navbar navbar-expand-md navbar-light bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" >Employee Tracker</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Add Skills</a>
        </li>
       
        
        <li class="nav-item">
          <a class="nav-link active" href="#" >Project</a>
        </li>
      </ul>
      <form class="d-flex">
        
      <Link to="/login"><button type="button" class="btn btn-success">Login</button></Link>
      
      </form>
    </div>
  </div>
</nav>
<div className="container mt-5 w-50  " >
 <form onSubmit={this.submitForm}>
     <div class="form-group mt-4">
         <h4 className="mb-4">Login Form</h4>
    <input type="text"  class="form-control" placeholder="username" name="usernam" placeholder="Enter your username" required value={this.state.usernam}onChange={this.onChange}/><br/>
    </div>
  <div class="form-group">
    <input type="password" class="form-control"placeholder="password" required placeholder="Enter your password" name="password" value={this.state.password}onChange={this.onChange}/><br/>
</div>
 
<button type ="submit" className="btn btn-primary mb-3">Submit</button>
</form>
</div>
</div>
        );
    }
}
