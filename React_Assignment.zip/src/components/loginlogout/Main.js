

import {BrowserRouter as Router,Route,Switch  } from "react-router-dom";
// import Homes from './home/Homes';
import Login from '../loginlogout/Login';
import Services from './ServicesLog';
import Logout from './ServicesLog';


function Main() {
  return (
   
   
    <Router>
    <div className="App">

      <Switch>
        <Route exact path="/"component={Login} ></Route>
        <Route path="/services"component={Services} ></Route>
        <Route  path="/logout"component={Logout} ></Route>
        <Route  path="/login"component={Login} ></Route>
    </Switch>
   
    </div>
    </Router>
    

  );
}

export default Main;