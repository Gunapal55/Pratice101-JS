import React from "react";

const DEFAULT_PLACEHOLDER_IMAGE =
  "http://motivatevalmorgan.com/wp-content/uploads/2016/06/default-movie-1-3.jpg";


const Movie = ({ movie }) => {
  const poster =
    movie.Poster === "N/A" ? DEFAULT_PLACEHOLDER_IMAGE : movie.Poster;
  return (
    <div className="movie">
     
      <div>
        <img
          width="200"
          height="290"
          alt={`The movie titled: ${movie.Title}`}
          src={poster}
        />
      </div>
      <h2>{movie.Title}</h2>
      <p>({movie.Year})</p>
      
    </div>
  );
};


export default Movie;