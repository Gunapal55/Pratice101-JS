import React from "react";
import './MoviesReactApp.css';
import Navbar from 'react-bootstrap/Navbar';

const Header = (props) => {
  return (
    <Navbar bg="dark" variant="dark">
    <Navbar.Brand href="#home">
      <img
        alt=""
        src="https://apkvision.com/wp-content/uploads/2019/12/My-Movies-Pro-Movie-TV-Collection-Library.png"
        width="40"
        height="37"
        className="d-inline-block align-top"
      /> 
       Movie Buzz
    </Navbar.Brand>
  </Navbar> );
};

export default Header;