import React, {Component} from 'react'; 
import Container from 'react-bootstrap/Container'; 
import Row from 'react-bootstrap/Row'; 
import Col from 'react-bootstrap/Col'; 
import Button from 'react-bootstrap/Button'; 
import InputGroup from 'react-bootstrap/InputGroup'; 
import FormControl from 'react-bootstrap/FormControl'; 
import ListGroup from 'react-bootstrap/ListGroup'; 
import './Todo.css';

class TodoList extends Component { 
constructor(props) { 
	super(props); 
 
	this.state = { 
	userInput : "", 
	list:[] 
	} 
} 

updateInput(value){ 
	this.setState({ 
	userInput: value, 
	}); 
} 


addItem(){ 
	if(this.state.userInput !== '' ){ 
	const userInput = { 

		id : Math.random(), 
      
		value : this.state.userInput 
	}; 
    console.log(this.id);
 
	const list = [...this.state.list]; 
	list.push(userInput); 

	this.setState({ 
		list, 
		userInput:""
	}); 
	} 
} 

deleteItem(key){ 
	const list = [...this.state.list]; 

	const updateList = list.filter(item => item.id !== key); 

	this.setState({ 
	list:updateList, 
	}); 
} 

render(){ 
	return(
    <Container> 
        <Row style={{ 
                color: 'white',
				display: "flex", 
				justifyContent: "center", 
				alignItems: "center", 
				fontSize: '3rem', 
                fontWeight: 'bolder', 
                backgroundColor: 'black',
                marginBottom: '20px '
				}} 
				>TO-DO LIST 
			</Row> 
    <Row> 
		<Col md={{ span: 5, offset: 4 }}> 

		<InputGroup className="mb-3"> 
		<FormControl 
			placeholder="E.g: Finish Study by 5pm.. "
			size="lg"
			value = {this.state.userInput} 
			onChange = {item => this.updateInput(item.target.value)} 
			aria-label="add something"
            aria-describedby="basic-addon2"
            required    
		/> 
		<InputGroup.Append> 
            <img 
            src="https://www.flaticon.com/svg/vstatic/svg/2891/2891642.svg?token=exp=1612504375~hmac=2c36d99fa7c03e091c6a491fc259c382"
			onClick = {()=>this.addItem()} 
			style={{height: '55px'}}
            > 
			</img> 
		</InputGroup.Append> 
		</InputGroup> 

	</Col> 
</Row> 
<Row> 
	<Col md={{ span: 5, offset: 4 }}> 
		<ListGroup> 

		{this.state.list.map(item => {return( 

            <ListGroup.Item varient="success" >{item.value}<img src="https://www.flaticon.com/svg/vstatic/svg/190/190411.svg?token=exp=1612504967~hmac=752e3709b97e21999539bd05964b6a46" id="delbtn"  onClick ={()=> this.deleteItem(item.id)}></img> </ListGroup.Item>

		)})} 
		</ListGroup> 
	</Col> 
</Row> 
	</Container> 
	); 
} 
} 

export default TodoList; 
