import logo from './logo.svg';
import './App.css';
import Register from './components/registeremp/Register';
import Table from './components/register/Table';
import MoviesReactApp from './components/moviesappreact/MoviesReactApp';
import ClippedDrawer from './components/registeremp/Register';
import TodoList from './components/todolist/TodoList';
import Main from './components/loginlogout/Main';

function App() {
  return (
    <div>
      {/* <Register /> */}
  {/* <Table /> */}
    {/* <MoviesReactApp /> */}
    {/* <ClippedDrawer /> */}
    {/* <TodoList /> */}
    <Main />
    </div>
  );
}

export default App;
