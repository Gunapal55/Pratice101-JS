import React, { useReducer } from "react";
import { Button, Icon, TextField, Paper, Typography } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import 'date-fns';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import { spacing } from '@material-ui/system';
import DateFnsUtils from '@date-io/date-fns';
import Container from '@material-ui/core/Container';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import { ValidatorComponent } from 'react-material-ui-form-validator';
import Select from '@material-ui/core/Select';
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from '@material-ui/pickers';

export function MaterialUIFormSubmit(props) {
  const [selectedDate, setSelectedDate] = React.useState(new Date(''));

  const handleDateChange = (date) => {
    setSelectedDate(date);
  };
  const useStyles = makeStyles((theme) => ({
    button: {
      margin: theme.spacing(1),
      marginTop: 20,
      marginLeft: 320
    },
    leftIcon: {
      marginRight: theme.spacing(1)
    },
    rightIcon: {
      marginLeft: theme.spacing(1)
    },
    iconSmall: {
      fontSize: 20
    },
    root: {
      padding: theme.spacing(3, 2)
    },
    container: {
      display: "flex",
      flexWrap: "wrap"
    },
    textField: {
      marginLeft: theme.spacing(1),
      marginRight: theme.spacing(1),
      width: 400
    }
  }));

  const [formInput, setFormInput] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      name: "",
      email: ""
    }
  );

  const handleSubmit = (evt) => {
    evt.preventDefault();
 
    let data = { formInput };
    console.log(data);
  }
  //   fetch("https://pointy-gauge.glitch.me/api/form", {
  //     method: "POST",
  //     body: JSON.stringify(data),
  //     headers: {
  //       "Content-Type": "application/json"
  //     }
  //   })
  //     .then((response) => response.json())
  //     .then((response) => console.log("Success:", JSON.stringify(response)))
  //     .catch((error) => console.error("Error:", error));
  // };

  const handleInput = (evt) => {
    const name = evt.target.name;
    const newValue = evt.target.value;
    setFormInput({ [name]: newValue });
  };

  const classes = useStyles();

  console.log(props);

  return (
    
      <Container maxWidth="sm" >
      <h1 className="align-center">Mock Feed Back</h1>
      <Paper className={classes.root}>
        <Typography variant="h5" component="h3">
          {props.formName}
        </Typography>
        <Typography component="p">{props.formDescription}</Typography>

        <form onSubmit={handleSubmit}>
          <Box m={0.5} p={0.2}>
          <TextField
            label="Employee ID"
            id="margin-normal"
            
            name="name"
            defaultValue={formInput.email}
            className={classes.textField}
            error
            helperText="Enter Employee Id"
            onChange={handleInput}
          />
        </Box>
        <Box m={0.5} p={0.2}>
          <TextField
            label="Full Name"
            id="margin-normal"
            name="Full Name"
            defaultValue={formInput.name}
            className={classes.textField}
            error
            helperText="Please enter the fullname"
            onChange={handleInput}
          />
          </Box>
          <Box m={0.5} p={0.2}>
          <TextField
            label="Mock Taken By"
            id="margin-normal"
            name="name"
            defaultValue={formInput.email}
            className={classes.textField}
            error
            helperText="Please fill this filed"
            onChange={handleInput}
          />
        </Box>
      <Box m={0.5} p={0.2}>
       <TextField
        id="date"
        label="Mock Date"
        type="date"
        helperText="please select date"
        defaultValue="YYYY-MM-DD"
        error
        className={classes.textField}
        InputLabelProps={{
          shrink: true,
        }}
      /> </Box>
       <Box m={0.5} p={0.2}>
          <TextField
            label="Technology"
            id="margin-normal"
            name="name"
            defaultValue={formInput.email}
            className={classes.textField}
            error
            helperText="Please enter the techology"
            onChange={handleInput}
          /></Box>
       <Box m={0.5} p={0.2}>
          <TextField
            label="Therotical Knowledeg (out of 100)"
            id="margin-normal"
            name="number"
            defaultValue={formInput.email}
            className={classes.textField}
            error
            helperText="Require Rating"
            onChange={handleInput}
          /></Box>
        <Box m={0.5} p={0.2}>
          <TextField
            label="Practical Knowledge(out of 100)"
            id="margin-normal"
            name="number"
            defaultValue={formInput.name}
            className={classes.textField}
            error
            helperText="Require Rating"
            onChange={handleInput}
          /></Box>
         <Box m={0.5} p={0.2} pb={1}>
          <TextField
            label="Action Item"
            id="margin-normal"
            name="name"
            defaultValue={formInput.email}
            className={classes.textField}
           onChange={handleInput}
          /> </Box>
           <Box mx={1} width="100%" p={1}>
        
            <Select labelId="label" id="select" error helperText="Please select a rating" value="choose"> 
              <MenuItem value="choose">Select Overall Feedback</MenuItem>
              <MenuItem >Excellent</MenuItem>
              <MenuItem >Good</MenuItem>
              <MenuItem >Above Average</MenuItem>
              <MenuItem >Average</MenuItem>
              <MenuItem >Below Average</MenuItem>
            </Select>
            </Box>
            <Box m={0.5}  p={0.2}>
            <TextField
            label="Detailed Feedback"
            id="margin-normal"
            name="name"
            rows={2}
            rowsMax={4}
            defaultValue={formInput.name}
            className={classes.textField}
            onChange={handleInput}
          />        
         </Box>
         <Box mx="auto" p={0.2}>
            <Button
            type="submit"
            variant="contained"
            color="primary"
            className={classes.button}
          >
            Submit
          </Button>
        </Box>
        </form>
      </Paper>
      </Container>
     
  );
}
