import './App.css';
import { BrowserRouter as Router, Route } from "react-router-dom";

import EmployeeForm from './components/pages/Employees/EmployeeForm';


function App() {
  return (
    <div>
     <EmployeeForm />
    {/* <BasicExample /> */}
{/* <Router>
    <div className="App">
      <PrimarySearchAppBar/>
      <Route path="/signin" exact component={SignInSide} />
      <Route exact path="/signup" component={SignUp} />
      <Route exact path="/feedbackform" component={EmployeeForm} />
    
      <Route exact path="/feedback" component={MaterialUIFormSubmit} />
    </div>  
</Router>  */}
                 


  </div>
  );
}
export default App;
